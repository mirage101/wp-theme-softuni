<?php 
/**
 * Proper way to enqueue scripts and styles.
 */
function softuni_assets($hook) {
    

    $args = array(
        'in_footer' => true,
        'strategy'  => 'defer',
    );

    $main_css = get_template_directory_uri() . '/assets/css/style.css';

    
    wp_enqueue_script( 'wow', get_template_directory_uri() . '/assets/lib/wow/wow.min.js', array(), '1.0.0', $args );
    wp_enqueue_script( 'easing', get_template_directory_uri() . '/assets/lib/easing/easing.min.js', array(), '1.0.0', $args );
    wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/assets/lib/waypoints/waypoints.min.js', array(), '1.0.0', $args );
    wp_enqueue_script( 'owl.carousel', get_template_directory_uri() . '/assets/lib/owlcarousel/owl.carousel.min.js', array(), '1.0.0', $args );
	wp_enqueue_script( 'softuni-scripts', get_template_directory_uri() . '/assets/js/main.js', array( 'jquery' ), '1.0.3', $args );

    

    wp_enqueue_style( 'bootstrap.min-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css', false, '1.0.0' );
    wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/lib/animate/animate.min.css', false, '1.0.0' );
    wp_enqueue_style( 'easing', get_template_directory_uri() . '/assets/lib/easing/easing.min.css', false, '1.0.0' );
    wp_enqueue_style( 'owl.carousel.css', get_template_directory_uri() . '/assets/lib/owlcarousel/assets/owl.carousel.min.css', false, '1.0.0' );
    wp_enqueue_style( 'style.css', get_template_directory_uri() . '/assets/css/style.css', false, '1.0.0' );
    
}
add_action( 'wp_enqueue_scripts', 'softuni_assets' );


/**
 * Register our navigation menus
 *
 * @return void
 */
// function softuni_register_nav_menus() {
// 	register_nav_menus(
// 		array(
// 			'primary_menu'      => __( 'Primary Menu', 'softuni-elearning' ),
// 			'popular_services'  => __( 'Popular Services', 'softuni-elearning' ),
// 			'important_links'   => __( 'Important Links', 'softuni-elearning' ),
//             'latest_services'   => __( 'Latest Services', 'softuni-elearning' )
// 		)
// 	);
// }
// add_action( 'after_setup_theme', 'softuni_register_nav_menus' );
?>