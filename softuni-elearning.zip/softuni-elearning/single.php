<?php get_header(); ?>


    <?php if (have_posts() ): ?>

        <?php while ( have_posts() ) : the_post(); ?>

    <!-- Header Start -->
        <div class="container-fluid bg-primary py-5 mb-5 page-header">
            <div class="container py-5">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center">
                        <h1 class="display-3 text-white animated slideInDown"><?php the_title();?></h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                                <li class="breadcrumb-item text-white active" aria-current="page"><?php the_title();?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            </div>    
 <!-- Header End -->
            <div class="row">
                <div class="inner-container">
                    <?php the_content();?>
                </div>
            </div>
        <?php endwhile; ?>

    <?php else: ?>
        Sorry, I couldn't find posts

<?php endif; ?>


<?php get_footer(); ?>